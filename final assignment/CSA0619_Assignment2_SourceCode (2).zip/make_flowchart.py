import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

fig, ax = plt.subplots(figsize=(9, 12))
ax.set_xlim(0, 10)
ax.set_ylim(0, 26)
ax.axis("off")

boxes = [
    ("Real-World Geospatial Dataset\n(OpenFlights airports.dat)", "#e8f0fe", "#1a73e8"),
    ("Data Preparation\n(parse, validate, extract (lon, lat) points,\nsample n points)", "#e8f0fe", "#1a73e8"),
    ("Brute-Force\nImplementation\n\u0398(n\u00b2)", "#fde8e8", "#d93025"),
    ("Divide-and-Conquer\nImplementation\n\u0398(n log n)", "#e6f4ea", "#137333"),
    ("Hybrid Algorithm Development\n(D&C + Brute-Force switch)", "#fff3e0", "#e37400"),
    ("Threshold Determination\n(experimental sweep of T)", "#fff3e0", "#e37400"),
    ("Complexity Analysis\nBig-O / \u03a9 / \u0398 + Master Theorem", "#f3e8fd", "#8430ce"),
    ("Experimental Evaluation\n(time, comparisons, memory,\nincreasing input size)", "#e8f0fe", "#1a73e8"),
    ("Optimization\n(select best T, validate correctness)", "#fff3e0", "#e37400"),
    ("Performance Comparison\n(Brute Force vs D&C vs Hybrid)", "#e6f4ea", "#137333"),
    ("Final Engineering Decision\n(recommend Hybrid for large-scale data)", "#fde8e8", "#d93025"),
]

y = 25
positions = []
box_h = 1.7
gap = 0.6
for text, face, edge in boxes:
    x0, w = 1.0, 8.0
    box = FancyBboxPatch((x0, y - box_h), w, box_h,
                          boxstyle="round,pad=0.08,rounding_size=0.15",
                          linewidth=1.8, edgecolor=edge, facecolor=face)
    ax.add_patch(box)
    ax.text(x0 + w / 2, y - box_h / 2, text, ha="center", va="center",
            fontsize=10.5, fontweight="medium", color="#202124")
    positions.append((x0 + w / 2, y - box_h, x0 + w / 2, y))
    y -= (box_h + gap)

for i in range(len(positions) - 1):
    x_top, y_bottom_of_prev, _, _ = positions[i]
    x_bot, _, _, y_top_of_next = positions[i + 1]
    arrow = FancyArrowPatch((x_top, y_bottom_of_prev - 0.02), (x_bot, y_top_of_next + gap - 0.02 + (positions[i+1][3]-positions[i+1][1]) - (positions[i+1][3]-positions[i+1][1])),
                             arrowstyle="-|>", mutation_scale=18, color="#5f6368", linewidth=1.6)
    # simpler: straight vertical arrow between consecutive boxes
    ax.annotate("", xy=(x_bot, positions[i+1][3]), xytext=(x_top, y_bottom_of_prev),
                arrowprops=dict(arrowstyle="-|>", color="#5f6368", linewidth=1.8, mutation_scale=18))

ax.set_title("System Architecture — Hybrid Closest-Pair Solution Pipeline",
             fontsize=13, fontweight="bold", pad=14)

plt.tight_layout()
plt.savefig("system_architecture.png", dpi=160, bbox_inches="tight")
plt.close()
print("Flowchart saved.")
