"""
dataset.py
==========
Loads the real-world OpenFlights airports dataset and prepares coordinate
point-sets of increasing size for experimentation.

Source: https://github.com/jpatokal/openflights  (data/airports.dat)
Columns (no header in raw file):
 0 Airport ID, 1 Name, 2 City, 3 Country, 4 IATA, 5 ICAO,
 6 Latitude, 7 Longitude, 8 Altitude, 9 Timezone, 10 DST,
 11 Tz database time zone, 12 Type, 13 Source
"""

import csv
import random


def load_airport_points(path="airports.dat"):
    """Return a list of (longitude, latitude) tuples for every valid airport
    record. Longitude is used as X and Latitude as Y (planar approximation,
    adequate for a Closest-Pair distance-comparison exercise)."""
    points = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            try:
                lat = float(row[6])
                lon = float(row[7])
                points.append((lon, lat))
            except (ValueError, IndexError):
                continue
    return points


def sample_points(base_points, n, seed=42):
    """Deterministically sample (or, if n exceeds the dataset, sample with
    slight jitter-based augmentation) n points from the real dataset so that
    experiments can be run at sizes larger than the raw record count while
    still being grounded in real geospatial coordinates."""
    rng = random.Random(seed)
    if n <= len(base_points):
        return rng.sample(base_points, n)

    # augment: bootstrap real points with a small random jitter to reach
    # larger n while preserving the real dataset's spatial distribution
    pts = list(base_points)
    while len(pts) < n:
        src = rng.choice(base_points)
        jitter = (rng.uniform(-0.01, 0.01), rng.uniform(-0.01, 0.01))
        pts.append((src[0] + jitter[0], src[1] + jitter[1]))
    return pts[:n]


if __name__ == "__main__":
    pts = load_airport_points()
    print(f"Loaded {len(pts)} valid airport coordinate records.")
    print("Sample:", pts[:5])
