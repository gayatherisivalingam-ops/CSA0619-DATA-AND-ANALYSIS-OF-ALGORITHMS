"""
exp_scaling.py
==============
Evaluate Brute Force, Divide-and-Conquer, and the optimized Hybrid (T=24)
algorithm on increasing input sizes drawn from the real OpenFlights dataset.
Brute Force is skipped beyond a feasibility cap (O(n^2) blow-up).
"""
import csv
from closest_pair import (run_instrumented, brute_force,
                           divide_and_conquer, hybrid_closest_pair)
from dataset import load_airport_points, sample_points

SIZES = [100, 250, 500, 1000, 2000, 4000, 6000, 8000, 12000, 16000]
BRUTE_FORCE_CAP = 4000          # beyond this, O(n^2) brute force is infeasible per-run
HYBRID_THRESHOLD = 24            # experimentally determined (exp_threshold.py)

base = load_airport_points("airports.dat")

rows = []
print(f"{'n':>7} | {'Algorithm':<17} | {'Time(ms)':>10} | {'Comparisons':>12} | {'PeakMem(KB)':>11} | {'Distance':>10}")
print("-" * 85)

for n in SIZES:
    pts = sample_points(base, n, seed=123)

    if n <= BRUTE_FORCE_CAP:
        r = run_instrumented("Brute Force", brute_force, pts)
        rows.append((n, r.algorithm, r.time_sec * 1000, r.comparisons, r.peak_memory_kb, r.distance))
        print(f"{n:>7} | {r.algorithm:<17} | {r.time_sec*1000:>10.3f} | {r.comparisons:>12} | {r.peak_memory_kb:>11.2f} | {r.distance:>10.6f}")

    r = run_instrumented("Divide & Conquer", divide_and_conquer, pts)
    rows.append((n, r.algorithm, r.time_sec * 1000, r.comparisons, r.peak_memory_kb, r.distance))
    print(f"{n:>7} | {r.algorithm:<17} | {r.time_sec*1000:>10.3f} | {r.comparisons:>12} | {r.peak_memory_kb:>11.2f} | {r.distance:>10.6f}")

    r = run_instrumented("Hybrid", hybrid_closest_pair, pts, threshold=HYBRID_THRESHOLD)
    rows.append((n, r.algorithm, r.time_sec * 1000, r.comparisons, r.peak_memory_kb, r.distance))
    print(f"{n:>7} | {r.algorithm:<17} | {r.time_sec*1000:>10.3f} | {r.comparisons:>12} | {r.peak_memory_kb:>11.2f} | {r.distance:>10.6f}")

with open("results_scaling.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["n", "algorithm", "time_ms", "comparisons", "peak_mem_kb", "distance"])
    w.writerows(rows)

print("\nSaved -> results_scaling.csv")
