"""
closest_pair.py
================
Closest-Pair-of-Points: Brute Force, Divide-and-Conquer and an
experimentally-optimized Hybrid algorithm.

Dataset : OpenFlights airports.dat (real-world geospatial coordinates)
Author  : CSA0619 - Design and Analysis of Algorithms - Assignment 2
"""

import math
import random
import time
import tracemalloc
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# 1. Utility
# ---------------------------------------------------------------------------
def euclidean(p1, p2):
    """Standard Euclidean distance between two (x, y) points."""
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


@dataclass
class RunStats:
    """Container for one algorithm run's instrumentation data."""
    algorithm: str
    n: int
    distance: float = math.inf
    pair: tuple = None
    comparisons: int = 0
    time_sec: float = 0.0
    peak_memory_kb: float = 0.0


# ---------------------------------------------------------------------------
# 2. Brute Force  ->  Theta(n^2)
# ---------------------------------------------------------------------------
def brute_force(points, count_ref=None):
    """
    Evaluate the distance of EVERY pair of points and keep the minimum.
    Time complexity : Theta(n^2)
    Space complexity: O(1) extra
    """
    n = len(points)
    best = math.inf
    best_pair = (None, None)
    comparisons = 0
    for i in range(n):
        for j in range(i + 1, n):
            comparisons += 1
            d = euclidean(points[i], points[j])
            if d < best:
                best = d
                best_pair = (points[i], points[j])
    if count_ref is not None:
        count_ref[0] += comparisons
    return best, best_pair, comparisons


# ---------------------------------------------------------------------------
# 3. Divide and Conquer -> Theta(n log n)
# ---------------------------------------------------------------------------
def _strip_closest(strip, d, best_pair, comparisons):
    """Scan the boundary strip; each point is compared against at most the
    next 7 points in the y-sorted strip (classic geometric proof)."""
    strip.sort(key=lambda p: p[1])
    m = len(strip)
    for i in range(m):
        j = i + 1
        while j < m and (strip[j][1] - strip[i][1]) < d:
            comparisons[0] += 1
            dist = euclidean(strip[i], strip[j])
            if dist < d:
                d = dist
                best_pair[0] = (strip[i], strip[j])
            j += 1
    return d


def _closest_rec(px, py, comparisons):
    n = len(px)

    # Base case: brute force for tiny sub-problems (n <= 3)
    if n <= 3:
        best = math.inf
        best_pair = (None, None)
        for i in range(n):
            for j in range(i + 1, n):
                comparisons[0] += 1
                d = euclidean(px[i], px[j])
                if d < best:
                    best, best_pair = d, (px[i], px[j])
        return best, best_pair

    mid = n // 2
    mid_point = px[mid]

    left_x, right_x = px[:mid], px[mid:]
    mid_set = set(id(p) for p in left_x)
    left_y = [p for p in py if id(p) in mid_set]
    right_y = [p for p in py if id(p) not in mid_set]

    d_left, pair_left = _closest_rec(left_x, left_y, comparisons)
    d_right, pair_right = _closest_rec(right_x, right_y, comparisons)

    if d_left < d_right:
        d, best_pair = d_left, pair_left
    else:
        d, best_pair = d_right, pair_right

    strip = [p for p in py if abs(p[0] - mid_point[0]) < d]
    holder_pair = [best_pair]
    d = _strip_closest(strip, d, holder_pair, comparisons)
    return d, holder_pair[0]


def divide_and_conquer(points):
    """
    Recursively partitions the point set about the median x-coordinate and
    evaluates points across the dividing strip.
    Recurrence : T(n) = 2T(n/2) + O(n)  ->  Theta(n log n)  [Master Theorem, case 2]
    """
    px = sorted(points, key=lambda p: p[0])
    py = sorted(points, key=lambda p: p[1])
    comparisons = [0]
    d, pair = _closest_rec(px, py, comparisons)
    return d, pair, comparisons[0]


# ---------------------------------------------------------------------------
# 4. Hybrid Algorithm -> switches to Brute Force below threshold T
# ---------------------------------------------------------------------------
def _hybrid_rec(px, py, comparisons, threshold):
    n = len(px)

    if n <= threshold:
        best = math.inf
        best_pair = (None, None)
        for i in range(n):
            for j in range(i + 1, n):
                comparisons[0] += 1
                d = euclidean(px[i], px[j])
                if d < best:
                    best, best_pair = d, (px[i], px[j])
        return best, best_pair

    mid = n // 2
    mid_point = px[mid]

    left_x, right_x = px[:mid], px[mid:]
    mid_set = set(id(p) for p in left_x)
    left_y = [p for p in py if id(p) in mid_set]
    right_y = [p for p in py if id(p) not in mid_set]

    d_left, pair_left = _hybrid_rec(left_x, left_y, comparisons, threshold)
    d_right, pair_right = _hybrid_rec(right_x, right_y, comparisons, threshold)

    if d_left < d_right:
        d, best_pair = d_left, pair_left
    else:
        d, best_pair = d_right, pair_right

    strip = [p for p in py if abs(p[0] - mid_point[0]) < d]
    holder_pair = [best_pair]
    d = _strip_closest(strip, d, holder_pair, comparisons)
    return d, holder_pair[0]


def hybrid_closest_pair(points, threshold=32):
    """
    Divide-and-Conquer that switches to Brute-Force once a sub-problem's
    size falls to `threshold` or below. `threshold` is determined
    experimentally (see experiments.py).
    """
    px = sorted(points, key=lambda p: p[0])
    py = sorted(points, key=lambda p: p[1])
    comparisons = [0]
    d, pair = _hybrid_rec(px, py, comparisons, threshold)
    return d, pair, comparisons[0]


# ---------------------------------------------------------------------------
# 5. Instrumented runner (time + peak memory)
# ---------------------------------------------------------------------------
def run_instrumented(algo_name, func, points, **kwargs):
    tracemalloc.start()
    t0 = time.perf_counter()
    dist, pair, comparisons = func(points, **kwargs)
    t1 = time.perf_counter()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return RunStats(
        algorithm=algo_name,
        n=len(points),
        distance=dist,
        pair=pair,
        comparisons=comparisons,
        time_sec=t1 - t0,
        peak_memory_kb=peak / 1024.0,
    )


# ---------------------------------------------------------------------------
# 6. Quick self-test when run directly
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    random.seed(42)
    pts = [(random.uniform(0, 1000), random.uniform(0, 1000)) for _ in range(500)]

    bf = run_instrumented("Brute Force", brute_force, pts)
    dc = run_instrumented("Divide & Conquer", divide_and_conquer, pts)
    hy = run_instrumented("Hybrid (T=32)", hybrid_closest_pair, pts, threshold=32)

    for r in (bf, dc, hy):
        print(f"{r.algorithm:20s} n={r.n:6d}  dist={r.distance:.6f}  "
              f"comparisons={r.comparisons:8d}  time={r.time_sec*1000:8.3f} ms  "
              f"peakMem={r.peak_memory_kb:8.2f} KB")

    assert abs(bf.distance - dc.distance) < 1e-9
    assert abs(bf.distance - hy.distance) < 1e-9
    print("\nCorrectness check PASSED: all three algorithms agree.")
