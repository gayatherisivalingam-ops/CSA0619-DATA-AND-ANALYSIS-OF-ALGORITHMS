"""
exp_threshold.py
================
Experimentally determine the best switching threshold T for the Hybrid
algorithm by fixing a moderately large n and sweeping T.
"""
import csv
from closest_pair import run_instrumented, hybrid_closest_pair
from dataset import load_airport_points, sample_points

FIXED_N = 4000
THRESHOLDS = [2, 4, 8, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]
TRIALS = 3  # repeat and average to reduce noise

base = load_airport_points("airports.dat")
pts = sample_points(base, FIXED_N, seed=7)

rows = []
print(f"Threshold sweep at n = {FIXED_N}  (avg of {TRIALS} trials)\n")
print(f"{'Threshold':>10} | {'Time(ms)':>10} | {'Comparisons':>12}")
print("-" * 38)
for T in THRESHOLDS:
    times, comps = [], []
    for trial in range(TRIALS):
        r = run_instrumented("Hybrid", hybrid_closest_pair, pts, threshold=T)
        times.append(r.time_sec * 1000)
        comps.append(r.comparisons)
    avg_time = sum(times) / len(times)
    avg_comp = sum(comps) / len(comps)
    rows.append((T, avg_time, avg_comp))
    print(f"{T:>10} | {avg_time:>10.3f} | {avg_comp:>12.0f}")

with open("results_threshold.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["threshold", "avg_time_ms", "avg_comparisons"])
    w.writerows(rows)

best = min(rows, key=lambda r: r[1])
print(f"\nBest threshold by execution time: T = {best[0]}  ({best[1]:.3f} ms)")
