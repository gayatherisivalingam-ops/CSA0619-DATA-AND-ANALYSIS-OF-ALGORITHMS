import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def read_scaling():
    data = {}
    with open("results_scaling.csv") as f:
        r = csv.DictReader(f)
        for row in r:
            algo = row["algorithm"]
            data.setdefault(algo, {"n": [], "time": [], "comp": [], "mem": []})
            data[algo]["n"].append(int(row["n"]))
            data[algo]["time"].append(float(row["time_ms"]))
            data[algo]["comp"].append(int(row["comparisons"]))
            data[algo]["mem"].append(float(row["peak_mem_kb"]))
    return data

def read_threshold():
    T, time_, comp = [], [], []
    with open("results_threshold.csv") as f:
        r = csv.DictReader(f)
        for row in r:
            T.append(int(row["threshold"]))
            time_.append(float(row["avg_time_ms"]))
            comp.append(float(row["avg_comparisons"]))
    return T, time_, comp

data = read_scaling()
colors = {"Brute Force": "#d62728", "Divide & Conquer": "#1f77b4", "Hybrid": "#2ca02c"}
markers = {"Brute Force": "o", "Divide & Conquer": "s", "Hybrid": "^"}

# ---- Chart 1: Execution time vs n (linear) ----
plt.figure(figsize=(7, 5))
for algo, d in data.items():
    plt.plot(d["n"], d["time"], marker=markers[algo], color=colors[algo], label=algo)
plt.xlabel("Input size (n)")
plt.ylabel("Execution time (ms)")
plt.title("Execution Time vs Input Size")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_time_linear.png", dpi=150)
plt.close()

# ---- Chart 2: Execution time vs n (log-log, shows growth-rate difference) ----
plt.figure(figsize=(7, 5))
for algo, d in data.items():
    plt.plot(d["n"], d["time"], marker=markers[algo], color=colors[algo], label=algo)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("Input size (n) [log scale]")
plt.ylabel("Execution time (ms) [log scale]")
plt.title("Execution Time vs Input Size (log-log)")
plt.legend()
plt.grid(alpha=0.3, which="both")
plt.tight_layout()
plt.savefig("chart_time_loglog.png", dpi=150)
plt.close()

# ---- Chart 3: Comparisons vs n ----
plt.figure(figsize=(7, 5))
for algo, d in data.items():
    plt.plot(d["n"], d["comp"], marker=markers[algo], color=colors[algo], label=algo)
plt.xlabel("Input size (n)")
plt.ylabel("Distance comparisons")
plt.title("Number of Distance Comparisons vs Input Size")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_comparisons.png", dpi=150)
plt.close()

# ---- Chart 4: Peak memory vs n ----
plt.figure(figsize=(7, 5))
for algo, d in data.items():
    plt.plot(d["n"], d["mem"], marker=markers[algo], color=colors[algo], label=algo)
plt.xlabel("Input size (n)")
plt.ylabel("Peak memory (KB)")
plt.title("Peak Memory Utilization vs Input Size")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_memory.png", dpi=150)
plt.close()

# ---- Chart 5: Threshold sweep ----
T, time_, comp = read_threshold()
fig, ax1 = plt.subplots(figsize=(7, 5))
ax1.plot(T, time_, marker="o", color="#2ca02c", label="Time (ms)")
ax1.set_xlabel("Switching threshold T")
ax1.set_ylabel("Execution time (ms)", color="#2ca02c")
ax1.tick_params(axis="y", labelcolor="#2ca02c")
best_idx = time_.index(min(time_))
ax1.scatter([T[best_idx]], [time_[best_idx]], color="black", zorder=5)
ax1.annotate(f"best T={T[best_idx]}", (T[best_idx], time_[best_idx]),
             textcoords="offset points", xytext=(10, 10))
ax2 = ax1.twinx()
ax2.plot(T, comp, marker="s", color="#9467bd", label="Comparisons")
ax2.set_ylabel("Distance comparisons", color="#9467bd")
ax2.tick_params(axis="y", labelcolor="#9467bd")
plt.title(f"Hybrid Threshold Sweep (n = 4000)")
fig.tight_layout()
plt.savefig("chart_threshold.png", dpi=150)
plt.close()

print("All charts generated.")
